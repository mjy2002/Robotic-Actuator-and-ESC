/*
 * foc.h
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */

#ifndef INC_FOC_H_
#define INC_FOC_H_


void setPhaseVoltage(float Uq, float Ud, float angle_el, TIM_HandleTypeDef *htim);


#endif /* INC_FOC_H_ */

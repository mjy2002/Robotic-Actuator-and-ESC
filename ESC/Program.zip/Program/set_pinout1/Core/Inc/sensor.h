/*
 * sensor.h
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */

#ifndef SENSOR_H
#define SENSOR_H

#ifdef __cplusplus
extern "C" {
#endif

#include <stdint.h>

/* 初期化処理 (初期の角度を読み取る) */
void Sensor_Init(void);

/* センサー値を更新して内部変数に保持する */
void Sensor_Update(void);

/* センサーが取得した最新の角度[ラジアン]を取得 */
float Sensor_GetAngleRad(void);

/* 回転数の取得 */
float Sensor_GetFullRotations(void);

float electricalAngle(void);

float NowAngle(void);


#ifdef __cplusplus
}
#endif

#endif /* SENSOR_H */


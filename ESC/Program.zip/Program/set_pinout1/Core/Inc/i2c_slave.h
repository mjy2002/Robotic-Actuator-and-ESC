/*
 * i2c_slave.h
 *
 *  Created on: Feb 18, 2025
 *      Author: taise
 */

#ifndef INC_I2C_SLAVE_H_
#define INC_I2C_SLAVE_H_



#endif /* INC_I2C_SLAVE_H_ */

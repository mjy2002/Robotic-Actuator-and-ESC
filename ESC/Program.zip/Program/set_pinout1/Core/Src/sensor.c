/*
 * sensor.c
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */


#include "sensor.h"
#include "main.h"
#include "i2c_slave.h"
#include "foc.h"
#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

# define _3PI_2 (3.0 * M_PI / 2.0)

#define MAGHIGH GPIO_PIN_0
#define MAGHIGH_PORT GPIOB
#define MAGLOW GPIO_PIN_1
#define MAGLOW_PORT GPIOB


/* extern で宣言すると main.c 側の hspi1 を使える */
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim1;


/* センサーの内部状態（静的変数） */
static float prev_angle_rad  = 0.0f;
static float full_rotations  = 0.0f;
static float zero_electric_angle = 0.0f;
static float voltage_align = 2.0f;
static float now_angle = 0.0f;
static float angle_el = 0.0f;


static int pole_pairs = 21;
static int sensor_direction = 1; //(1 or -1)




//磁気センサの状態をチェック
int CheckSensor(void)
{
    GPIO_PinState mag_high = HAL_GPIO_ReadPin(MAGHIGH_PORT, MAGHIGH);
    GPIO_PinState mag_low  = HAL_GPIO_ReadPin(MAGLOW_PORT, MAGLOW);

    if (mag_high == GPIO_PIN_RESET && mag_low == GPIO_PIN_RESET) {
        return 1;  // センサが有効
    }
    return 0;  // センサが無効
}



//角度を16ビットで読み取る関数 (元の static 関数)
static uint16_t ReadMagAlphaAngle(void)
{
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET); // CS=Low

    uint16_t txData = 0x0000;
    uint16_t rxData = 0x0000;

    /* 16ビット送受信 */
    HAL_StatusTypeDef ret = HAL_SPI_TransmitReceive(&hspi1,
        (uint8_t*)&txData, (uint8_t*)&rxData, 1, 100U);

    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);   // CS=High

    if (ret != HAL_OK){
        // 必要ならエラー処理
    }
    return rxData;
}

float _normalizeAngle(float angle) {
    while (angle > 2.0f * (float)M_PI) {
        angle -= 2.0f * (float)M_PI;
    }
    while (angle < 0) {
        angle += 2.0f * (float)M_PI;
    }
    return angle;
}

//初期化関数：最初に呼び出して初期の角度を保持する
void Sensor_Init(void)
{
    uint16_t angle16    = ReadMagAlphaAngle();      // 16ビット読み取り
    float mecAngleNum   = (float)(angle16 >> 4);    // 上位12ビット (0～4095)
    prev_angle_rad      = mecAngleNum * (2.0f * (float)M_PI) / 4096.0f;
    full_rotations      = 0.0f;
}

//角度更新：再度読み取って角度を計算し，回転数などを更新する
void Sensor_Update(void)
{
    // 1) 16ビット枠でデータを受信
    uint16_t angle16   = ReadMagAlphaAngle();

    // 2) 上位12ビットのみ取得 (0～4095)
    float mecAngleNum  = (float)(angle16 >> 4);

    // 3) 0~2πへ変換
    float angle_rad    = mecAngleNum * (2.0f * (float)M_PI) / 4096.0f;

    // 4) (必要なら)現在時刻を取得
    // uint32_t currentTime = __HAL_TIM_GET_COUNTER(&htim1);

    // 5) 前回からの角度変化量を計算
    float delta_angle  = angle_rad - prev_angle_rad;

    // 6) 角度変化量が0.8*2πよりも大きければ回転数を更新
    if (fabsf(delta_angle) > 0.8f * 2.0f * (float)M_PI) {
        full_rotations += (delta_angle > 0.0f) ? -1 : 1;
    }

    // 7) 前回角度を更新
    prev_angle_rad = angle_rad;

    //電気角を計算する
    angle_el = _normalizeAngle( (float)(sensor_direction * pole_pairs) * prev_angle_rad  - zero_electric_angle );

    //現在角度を計算する
    now_angle = ( ( 2.0f * (float)M_PI ) * full_rotations ) + prev_angle_rad;
}

//直前の角度(rad)を返す
float Sensor_GetAngleRad(void)
{
    return prev_angle_rad;
}

//回転数を返す
float Sensor_GetFullRotations(void)
{
    return full_rotations;
}

//電気角を返す
float electricalAngle(void){
	return angle_el;
}

//現在角度を返す
float NowAngle(void)
{
	return now_angle;
}

//ゼロ電気角を設定する
void alignSensor(void){
	setPhaseVoltage(voltage_align, 0, _3PI_2, &htim1);
	HAL_Delay(700);
	Sensor_Update();
	zero_electric_angle = 0;
	zero_electric_angle = electricalAngle();
	HAL_Delay(20);
	setPhaseVoltage(0, 0, 0, &htim1);
	HAL_Delay(200);
}











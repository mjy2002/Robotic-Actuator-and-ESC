/*
 * foc.c
 *
 *  Created on: Feb 19, 2025
 *      Author: taise
 */


#include "main.h"
#include "sensor.h"
#include "i2c_slave.h"
#include <math.h>



#ifndef min
  #define min(a,b)  (( (a) < (b) ) ? (a) : (b))
#endif

#ifndef max
  #define max(a,b)  (( (a) > (b) ) ? (a) : (b))
#endif

#ifndef _constrain
  #define _constrain(x, min_val, max_val)  ( ((x)<(min_val)) ? (min_val) : (((x)>(max_val)) ? (max_val) : (x)) )
#endif



float Ualpha = 0;
float Ubeta = 0;
float Ua = 0;
float Ub = 0;
float Uc = 0;
#define _SQRT3_2  0.86602540378f
float center = 0;
#define VOLTAGE_POWER_SUPPLY 12.0f
#define VOLTAGE_LIMIT  (VOLTAGE_POWER_SUPPLY * 0.866f)
float dc_a = 0;
float dc_b = 0;
float dc_c = 0;



//PVPWMで出力
void setPhaseVoltage(float Uq, float Ud, float angle_el, TIM_HandleTypeDef *htim) {
    float _sa = sinf(angle_el);
    float _ca = cosf(angle_el);

    Ualpha =  _ca * Ud - _sa * Uq;
    Ubeta =  _sa * Ud + _ca * Uq;

    Ua = Ualpha;
    Ub = -0.5f * Ualpha + _SQRT3_2 * Ubeta;
    Uc = -0.5f * Ualpha - _SQRT3_2 * Ubeta;

    center = VOLTAGE_LIMIT / 2;
    float Umin = min(Ua, min(Ub, Uc));
    float Umax = max(Ua, max(Ub, Uc));
    center -= (Umax + Umin) / 2;
    Ua += center;
    Ub += center;
    Uc += center;

    Ua = _constrain(Ua, 0, VOLTAGE_LIMIT);
    Ub = _constrain(Ub, 0, VOLTAGE_LIMIT);
    Uc = _constrain(Uc, 0, VOLTAGE_LIMIT);

    dc_a = _constrain(Ua / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);
    dc_b = _constrain(Ub / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);
    dc_c = _constrain(Uc / VOLTAGE_POWER_SUPPLY, 0.0f, 1.0f);

    uint32_t period = __HAL_TIM_GET_AUTORELOAD(htim);
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_1, (uint32_t)(dc_a * (float)period));
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_2, (uint32_t)(dc_b * (float)period));
    __HAL_TIM_SET_COMPARE(htim, TIM_CHANNEL_3, (uint32_t)(dc_c * (float)period));
}

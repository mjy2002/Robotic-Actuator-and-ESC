/*
 * i2c_slave.c
 *
 *  Created on: Feb 18, 2025
 *      Author: taise
 */


#include "main.h"
#include "i2c_slave.h"
#include "sensor.h"

//test
extern float angle_el;
extern float dc_a;
extern float dc_b;
extern float dc_c;
extern float Ualpha;
extern float Ubeta;
extern float Ua;
extern float Ub;
extern float Uc;

extern  float current_a;
extern  float current_b;
extern  float current_c;



extern float vq;
extern float vd;
extern float iq;
extern float id;

extern float goal_angle;
extern float add;


//I2Cで必要な最小限コード-------------------------------------------------


float selectData = 0;
float getData = 0;
float sendData = 0;


//i2cでやり取りするメモリサイズを決定(RX受信，TX送信）
#define RxSize 5
#define TxSize 5
static uint8_t RxData[RxSize] = {0};
static uint8_t TxData[TxSize] = {0};

void HAL_I2C_ListenCpltCallback(I2C_HandleTypeDef *hi2c)
{
	HAL_I2C_EnableListen_IT(hi2c);
}


void HAL_I2C_AddrCallback(I2C_HandleTypeDef *hi2c, uint8_t TransferDirection, uint16_t AddrMatchCode)
{
	if(TransferDirection == I2C_DIRECTION_TRANSMIT)
	{
		HAL_I2C_Slave_Sequential_Receive_IT(hi2c, RxData, RxSize, I2C_FIRST_AND_LAST_FRAME);
	}
	else
	{
		HAL_I2C_Slave_Sequential_Transmit_IT(hi2c, TxData, TxSize, I2C_FIRST_AND_LAST_FRAME);
	}
}


void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef* hi2c)
{
	memset(TxData, 0, TxSize);
    float Data = *((float*) (RxData + 1));

    switch (RxData[0])//データに応じて値を決定
    {
    case 0x01: // モータON
    {
    	selectData = 1;
    	break;
    }
    // 0x1- : マスターへの情報準備
    case 0x11:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &(sendData);
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x12:
	{
		float val = Sensor_GetAngleRad();
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x13:
	{
		float val = Sensor_GetFullRotations();
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x14:
	{
		float val = electricalAngle();
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x15:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &dc_a;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x16:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &dc_b;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x17:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &dc_c;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x18:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &Ualpha;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x19:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &Ubeta;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1a:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &Ua;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1b:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &Ub;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x1c:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &Uc;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x30:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_a;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x31:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_b;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x32:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &current_c;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
    case 0x34:
    {
    	TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &vq;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }
    case 0x35:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &vd;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;

	}
    case 0x36:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &iq;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;

	}
    case 0x37:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &id;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;

	}
    case 0x38:
    {
    	float val = NowAngle();
    	TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &val;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
    }




    // 0x2- : マスターから情報を受け取る
	case 0x21:
	{
		getData = Data;
		break;
	}
	case 0x22:
	{
		goal_angle = Data;
		break;
	}
	case 0x23:
	{
		TxData[0] = RxData[0];
		unsigned char* backData = (unsigned char*) &goal_angle;
		for (int i = 0; i < 4; i++) {
			TxData[i + 1] = *(backData + i);
		}
		break;
	}
	case 0x24:
	{
		add = Data;
		break;
	}

	default:
		break;
    }
}




